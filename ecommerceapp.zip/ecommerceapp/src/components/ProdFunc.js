import { DeleteProd } from "./PRODUCT"
export default function ProductFunc(){
    return (
        <div className='text-center'>
        <a href="/addproduct" className='btn btn-warning m-3'>Add Product</a>
       
        <a href="/listallproduct" className='btn btn-dark  m-3'>List All Product</a>
        <a href="/getprodbyid" className='btn btn-primary  m-3'>GetById</a>
        <a href="/getprodbyname" className='btn btn-light  m-3'>GetByName</a>
        <a href="/updatebyid" className='btn btn-warning  m-3'>UpdateById</a>
        <a href="/updatebyname" className='btn btn-success  m-3'>UpdateByName</a>
       <DeleteProd />
  
     
       </div>
    )
}