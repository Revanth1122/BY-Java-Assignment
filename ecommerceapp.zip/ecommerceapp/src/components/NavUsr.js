export default function NavbarUser(props){
    return (
        <div>
        <nav class="navbar navbar-expand-lg navbar-light prodbtn p-3">
        <a class="navbar-brand text-light tx" href="/products">E-COMMERCE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav  mx-auto justify-content-center">
        
          
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/listallproduct">ListOfProducts</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/listallcategory">ListOfCategories</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/getbyname">GetCategory&Prod</a>
            </li>
             <li className="nav-link mr-5">
             <div className="btn-group">
           <button type="button" className="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             {props.username}
           </button>
           <div className="dropdown-menu">
             <a className="dropdown-item" href="/getprodbyid">GetProdById</a>
             <a className="dropdown-item" href="/getprodbyname">GetProdByName</a>
             <a className="dropdown-item" href="/getbyid">GetCategoryByName</a>
             <div className="dropdown-divider"></div>
             <a className="dropdown-item" href="/logout">Logout</a>
           </div>
         </div>
             </li>
            
           
          </ul>
        </div>
      </nav>
      </div>
    )
}