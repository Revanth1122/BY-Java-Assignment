import { useState } from "react";
export default function NavbarUser(props){
  const [menuOpen, setMenuOpen] = useState(false);
    return (
        <div>
        <nav class="navbar navbar-expand-lg navbar-light prodbtn p-3">
        <a class="navbar-brand text-light tx" href="/products">E-COMMERCE</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation"
        onClick={() => setMenuOpen(!menuOpen)}
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")} id="navbarNavDropdown">
          <ul class="navbar-nav  mx-auto justify-content-center">
        
          
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/listallproduct">ListOfProducts</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/listallcategory">ListOfCategories</a>
            </li>
            <li class="nav-item">
              <a class="nav-link nvl text-light" href="/getbyname">GetCategory&Prod</a>
            </li>
             <li className="nav-link mr-5">
             <div className="btn-group">
           <button type="button" className="btn btn-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
             {props.username}
           </button>
           <div className="dropdown-menu">
             <a className="dropdown-item" href="/getprodbyid">GetProdById</a>
             <a className="dropdown-item" href="/getprodbyname">GetProdByName</a>
             <a className="dropdown-item" href="/getbyid">GetCategoryByName</a>
             <div className="dropdown-divider"></div>
             <a className="dropdown-item" href="/logout">Logout</a>
           </div>
         </div>
             </li>
            
           
          </ul>
        </div>
      </nav>
      </div>
    )
}

// import React, { useState } from "react";
// import { FaUserCircle } from "react-icons/fa";
// import { NavLink } from "react-router-dom";
// import { FaCartArrowDown } from "react-icons/fa";
// import { IoIosLogOut } from "react-icons/io";

// export default function NavbarUser (props)  {
//   const [menuOpen, setMenuOpen] = useState(false);

//   return (
//     <nav className="navbar navbar-expand-lg navbar-light prodbtn p-3">
//       <a className="navbar-brand text-light tx" href="/products">
//         E-COMMERCE
//       </a>
//       <button
//         className="navbar-toggler"
//         type="button"
//         data-toggle="collapse"
//         data-target="#navbarNavDropdown"
//         aria-controls="navbarNavDropdown"
//         aria-expanded="false"
//         aria-label="Toggle navigation"
//         onClick={() => setMenuOpen(!menuOpen)}
//       >
//         <span className="navbar-toggler-icon"></span>
//       </button>
//       <div className={"collapse navbar-collapse " + (menuOpen ? "show" : "")}>
//         <ul className="navbar-nav mx-auto justify-content-center">
//           <li className="nav-item">
//             <NavLink to="/listallproduct" className="nav-link nvl text-light">
//               ListOfProducts
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/listallcategory" className="nav-link nvl text-light">
//               ListOfCategories
//             </NavLink>
//           </li>
//           <li className="nav-item">
//             <NavLink to="/getbyname" className="nav-link nvl text-light">
//               GetCategory&Prod
//             </NavLink>
//           </li>
//           <li className="nav-link mr-5">
//             <div className="btn-group">
//               <button
//                 type="button"
//                 className="btn btn-primary dropdown-toggle"
//                 data-bs-toggle="dropdown"
//                 aria-haspopup="true"
//                 aria-expanded="false"
//               >
//                  <FaUserCircle /> {props.username}
//               </button>
//               <div className="dropdown-menu">
//                 <NavLink to="/getprodbyid" className="dropdown-item">
//                   GetProdById
//                 </NavLink>
//                 <NavLink to="/getprodbyname" className="dropdown-item">
//                   GetProdByName
//                 </NavLink>
//                 <NavLink to="/getbyid" className="dropdown-item">
//                   GetCategoryById
//                 </NavLink>
//                 <div className="dropdown-divider"></div>
//                 <NavLink to="/" className="dropdown-item">
//                   Logout   <IoIosLogOut />
//                 </NavLink>
//               </div>
//             </div>
//           </li>
        
         
//         </ul>
//       </div>
//     </nav>
//   );
// };
